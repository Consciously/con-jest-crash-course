export const sum = (sum1: number, sum2: number) => {
	return sum1 + sum2;
};
